# Adult Hypertension RAG System

A Retrieval-Augmented Generation (RAG) system specialized in clinical guidelines and best practices for adult hypertension management.

## Project Structure

```text
adult-hypertension-rag/
│
├── README.md
├── requirements.txt
├── .gitignore
├── .env.example
│
├── data/
│   ├── raw/
│   │   └── guidelines/       # Source clinical guidelines & PDF documents
│   └── processed/            # Processed text chunks, indexes & vector DBs
```

## Getting Started

### 1. Setup Environment
```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env` and fill in your credentials:
```bash
cp .env.example .env
```

### 3. Place Guidelines Data
Add raw guideline documents (PDFs, text files, clinical protocols) into `data/raw/guidelines/`.
