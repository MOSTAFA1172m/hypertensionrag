"""
gradio_app.py — free HF Spaces entry (Gradio SDK).

Replicates the Flask app's two features for the free Gradio Space tier:
  1. Ask: users ask hypertension questions and get grounded, cited answers.
  2. Admin - Upload Guideline: ingest a guideline PDF into the index.

In the Space repo this file is named app.py (the Gradio runtime runs app.py).
"""

import os
import shutil
import sys
from pathlib import Path

import gradio as gr

# HF Spaces runtime requires handlers to be decorated with @spaces.GPU (the
# `spaces` package is preinstalled there). Falls back to a no-op locally.
try:
    import spaces
except ImportError:  # pragma: no cover - local dev without the HF runtime
    spaces = None


def _gpu(duration: int):
    def deco(fn):
        if spaces is not None:
            return spaces.GPU(duration=duration)(fn)
        return fn

    return deco


# src/ on the path (same convention as app.py) so ingestion.* and rag.* import
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ingestion.auto_ingest import auto_ingest_pdf
from rag.rag_pipeline import answer, get_bm25_retriever, get_qdrant_client

DATA_DIR = Path(__file__).parent / "data"
PDF_DIR = DATA_DIR / "raw" / "guidelines"
MAX_TURNS = 6


@_gpu(duration=60)
def _chat_fn(message: str, history: list):
    turns = []
    for turn in history[-MAX_TURNS:]:
        if isinstance(turn, dict) and turn.get("role") in ("user", "assistant"):
            turns.append({"role": turn["role"], "content": turn.get("content", "")})

    try:
        result = answer(message, history=turns)
    except Exception as exc:  # e.g. GEMINI_API_KEY missing
        return (
            history
            + [
                {"role": "user", "content": message},
                {"role": "assistant", "content": f"Error: {exc}"},
            ],
            "",
        )

    sources_txt = "\n".join(
        f"[{i + 1}] {s.document_name} — {s.section_title} (p. {s.page_start})"
        for i, s in enumerate(result.sources)
    ) or "No sources retrieved."
    history = history + [
        {"role": "user", "content": message},
        {"role": "assistant", "content": result.answer},
    ]
    return history, sources_txt


def _file_path_and_name(file) -> tuple[Path | None, str | None]:
    if file is None:
        return None, None
    path = None
    orig = None
    if isinstance(file, dict):
        path, orig = file.get("path"), file.get("orig_name")
    else:
        path = getattr(file, "path", None) or getattr(file, "name", None)
        orig = getattr(file, "orig_name", None)
    if not path:
        return None, None
    return Path(path), (orig or Path(path).name)


@_gpu(duration=600)
def _ingest_pdf(pdf_path: str, orig_name: str, doc_name: str, org: str) -> str:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    safe = "".join(c for c in orig_name if c.isalnum() or c in "._- ").strip() or "guideline.pdf"
    dest = PDF_DIR / safe
    shutil.copyfile(pdf_path, dest)

    try:
        result = auto_ingest_pdf(
            pdf_path=dest,
            document_name=(doc_name or None),
            organization=(org or "Clinical Guideline"),
            qdrant_client=get_qdrant_client(),
            progress_callback=None,
        )
        get_bm25_retriever(force_reload=True)
        return f"Ingestion complete — {result['total_chunks']} chunks indexed."
    except Exception as exc:
        return f"Ingestion failed: {exc}"


def _admin_upload(file, doc_name: str, org: str) -> str:
    path, orig = _file_path_and_name(file)
    if path is None:
        return "No file selected."
    if not orig.lower().endswith(".pdf"):
        return "Only PDF files are supported."
    # pass plain strings across the spaces.GPU boundary (FileData doesn't pickle)
    return _ingest_pdf(str(path), orig, doc_name or "", org or "")


with gr.Blocks(title="Hypertension Guidelines RAG") as demo:
    gr.Markdown(
        "# Hypertension Guidelines RAG\n"
        "Ask questions about WHO, ESC, USPSTF and CDC hypertension guidelines. "
        "Answers are grounded in the guideline text and cite their sources."
    )

    with gr.Tab("Ask"):
        chatbot = gr.Chatbot(height=480, label="Conversation")
        sources_box = gr.Textbox(label="Sources", lines=4, interactive=False)
        msg = gr.Textbox(
            placeholder="e.g. What is the BP threshold for pharmacological treatment?",
            show_label=False,
        )
        clear = gr.ClearButton([chatbot, sources_box], value="Clear chat")

        msg.submit(_chat_fn, [msg, chatbot], [chatbot, sources_box]).then(
            lambda: "", None, msg
        )

    with gr.Tab("Admin — Upload Guideline"):
        gr.Markdown(
            "Upload a guideline PDF to index it. Parsing + embedding a large PDF "
            "takes a few minutes."
        )
        file_in = gr.File(label="Guideline PDF", file_types=[".pdf"])
        doc_name = gr.Textbox(label="Document name (optional)")
        org = gr.Textbox(label="Organization (optional)", value="Clinical Guideline")
        ingest_btn = gr.Button("Ingest")
        out = gr.Markdown()

        ingest_btn.click(_admin_upload, [file_in, doc_name, org], out)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "7860"))
    demo.launch(server_name="0.0.0.0", server_port=port, theme=gr.themes.Soft())